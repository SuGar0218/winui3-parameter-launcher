using Microsoft.UI.Xaml.Controls;

namespace ChromiumBasedAppLauncherGUI.Views;

public sealed partial class EmptyPage : Page
{
    public EmptyPage()
    {
        InitializeComponent();
    }
}
