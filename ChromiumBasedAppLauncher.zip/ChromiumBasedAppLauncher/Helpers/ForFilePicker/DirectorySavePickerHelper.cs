﻿using Microsoft.UI.Xaml;

namespace ChromiumBasedAppLauncherGUI.Helpers.ForFilePicker;

public abstract class DirectorySavePickerHelper : DirectoryPickerHelper
{
    protected DirectorySavePickerHelper(Window window) : base(window) { }
}
