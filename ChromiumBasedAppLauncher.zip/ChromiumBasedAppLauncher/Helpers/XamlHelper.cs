﻿namespace ChromiumBasedAppLauncherGUI.Helpers;

public static class XamlHelper
{
    public static double Muliply(double dip, double times) => dip * times;
}
