﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChromiumBasedAppLauncherGUI.Services;

public class HijackService
{
    public static void SetLauncher(string exe, string launcher)
    {
        
    }
}
